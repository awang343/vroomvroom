#!/bin/bash

########################################
############# CSCI 2951-O ##############
########################################

# Update this file with instructions on how to compile your code
uv venv p5_venv --python 3.9
source p5_venv/bin/activate
uv pip install -r requirements.txt
